#! /usr/bin/env python3
from perm_unique import perm_unique

LOWEST_NUMBER = 1   # Inclusive
HIGHEST_NUMBER = 4  # Inclusive
N_DUPLICATES = 3
CHUNKSIZE = 10000    # Report after every chunk


flat_list = [
    str(item)  # If we already convert here, we don't have to convert for every
               # permutation
    for item in range(LOWEST_NUMBER, HIGHEST_NUMBER + 1)
    for _ in range(N_DUPLICATES)
]

mid = len(flat_list) // 2

print("before perms")
perms = perm_unique(flat_list)
print("after perms")


# For-loops have a (very) small overhead,
# this was my attempt at removing it, but
# it didn't help much. I didn't feel like
# putting it back the way it was because
# I'm lazy and want to have some lunch. :)
def write_to(fd, mid):
    def inner(seq):
        fd.write("{}\n{}\n\n".format(
            " ".join(seq[:mid]),  # I'm splitting like this to not create an
            " ".join(seq[mid:]),  # additional list (of two lists) every time
        ))
    return inner


with open('file.txt', 'w') as wr:
    count = 0
    for _ in map(write_to(wr, mid), perms):
        count += 1
        if not count % CHUNKSIZE:
            print(count)
print("Total:", count)
print("Done!")
